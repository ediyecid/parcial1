public enum colores{
    Negro, Blanco, Azul, Verde, Gris
}
